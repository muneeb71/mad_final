import { View, Text, StyleSheet, FlatList, Pressable } from "react-native";
import React from "react";
import MaterialCommunityIcons from "react-native-vector-icons/FontAwesome";

const OrdersList = ({ navigation }) => {
  const generateOrder = ({ item }) => {
    return (
      <Pressable>
        <View style={styles.employee}>
          <Text style={styles.name}>{item.orderNumber}</Text>
          <Text style={styles.name}>{"$" + item.price}</Text>
          <View
            style={{
              display: "flex",
              flexDirection: "row",
              justifyContent: 'center',
              alignSelf: "center",
              borderWidth: 1,
              borderColor: "white",
              borderRadius: 4,
              width: "50%",
            }}
          >
            
            <MaterialCommunityIcons
              name="arrow-right"
              size={22}
              style={{  display: "flex",
              flexDirection: "row",
              alignSelf: "center",
              borderWidth: 1,
              borderColor: "#333333",
              borderRadius: 4,
              paddingHorizontal: 12,
              paddingVertical: 8,
              alignItems: "center",
              backgroundColor: "#333333",
              color: "white" }}
              onPress={() =>
                navigation.navigate("OrderDetails", {
                  orderNumber: item.orderNumber,
                  price: item.price,
                  productName: item.productName,
                  customer: item.customer,
                  orderDate: item.orderDate,
                  shippingStatus: item.shippingStatus,
                })
              }
            />
          </View>
        </View>
      </Pressable>
    );
  };
  const orders = [
    {
      orderNumber: "ORD001",
      productName: "Product 1",
      price: 19.99,
      customer: {
        name: "John Doe",
        email: "johndoe@example.com",
        address: "123 Main St, Anytown USA",
      },
      orderDate: "2022-01-01",
      shippingStatus: "Shipped",
    },
    {
      orderNumber: "ORD002",
      productName: "Product 2",
      price: 29.99,
      customer: {
        name: "Jane Smith",
        email: "janesmith@example.com",
        address: "456 High St, Anytown USA",
      },
      orderDate: "2022-01-02",
      shippingStatus: "Pending",
    },
    {
      orderNumber: "ORD003",
      productName: "Product 3",
      price: 9.99,
      customer: {
        name: "Bob Johnson",
        email: "bobjohnson@example.com",
        address: "789 Market St, Anytown USA",
      },
      orderDate: "2022-01-03",
      shippingStatus: "Delivered",
    },
    {
      orderNumber: "ORD004",
      productName: "Product 4",
      price: 39.99,
      customer: {
        name: "Alice Green",
        email: "alicegreen@example.com",
        address: "10 Elm St, Anytown USA",
      },
      orderDate: "2022-01-04",
      shippingStatus: "Shipped",
    },
    {
      orderNumber: "ORD005",
      productName: "Product 5",
      price: 14.99,
      customer: {
        name: "David Lee",
        email: "davidlee@example.com",
        address: "555 Pine St, Anytown USA",
      },
      orderDate: "2022-01-05",
      shippingStatus: "Pending",
    },
    {
      orderNumber: "ORD006",
      productName: "Product 6",
      price: 24.99,
      customer: {
        name: "Sarah Brown",
        email: "sarahbrown@example.com",
        address: "999 Oak St, Anytown USA",
      },
      orderDate: "2022-01-06",
      shippingStatus: "Delivered",
    },
    {
      orderNumber: "ORD007",
      productName: "Product 7",
      price: 49.99,
      customer: {
        name: "Timothy Davis",
        email: "timothydavis@example.com",
        address: "222 Maple St, Anytown USA",
      },
      orderDate: "2022-01-07",
      shippingStatus: "Shipped",
    },
    {
      orderNumber: "ORD008",
      productName: "Product 8",
      price: 12.99,
      customer: {
        name: "Olivia Williams",
        email: "oliviawilliams@example.com",
        address: "333 Birch St, Anytown USA",
      },
      orderDate: "2022-01-08",
      shippingStatus: "Pending",
    },
  ];

  return (
    <View style={styles.parent}>
      <FlatList
        data={orders}
        renderItem={(order) => generateOrder(order)}
        keyExtractor={(order) => order.orderNumber}
        contentContainerStyle={styles.scroll}
      ></FlatList>
    </View>
  );
};

const styles = StyleSheet.create({
  parent: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  employee: {
    borderWidth: 1,
    marginBottom: 8,
    width: "80%",
    borderRadius: 8,
    padding: 12,
    borderColor: "#e0e0e0",
    alignSelf: "center",
    backgroundColor: "#ffffff",
    shadowColor: "#000000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 2,
  },
  name: {
    fontSize: 16,
    textAlign: "center",
    color: "#333333",
    fontWeight: "bold",
    marginBottom: 8,
  },
  scroll: {
    paddingVertical: 24,
    paddingHorizontal: 16,
    backgroundColor: "#f5f5f5",
  },
});

export default OrdersList;
