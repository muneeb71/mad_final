import {View, Text, StyleSheet, FlatList, Pressable} from 'react-native';
import React from 'react';

const ProductDetails = ({navigation, route}) => {
  return (
    <View style={styles.parent}>
      <View style={styles.productContainer}>
        <Text style={styles.title}>Product Details</Text>
        <Text style={styles.label}>Name:</Text>
        <Text style={styles.text}>{route.params.name}</Text>
        <Text style={styles.label}>Price:</Text>
        <Text style={styles.text}>{'$' + route.params.price}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  parent: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    justifyContent: 'center',
  },
  productContainer: {
    backgroundColor: '#ffffff',
    marginHorizontal: 16,
    borderRadius: 8,
    padding: 16,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 2,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  text: {
    fontSize: 16,
    marginBottom: 8,
  },
});

export default ProductDetails;
