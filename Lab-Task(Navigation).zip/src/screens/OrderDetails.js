import { View, Text, StyleSheet } from 'react-native';
import React from 'react';

const OrderDetails = ({ navigation, route }) => {
  console.log(route.params.orderDate);
  return (
    <View style={styles.parent}>
      <View style={styles.orderContainer}>
        <Text style={styles.title}>Order Details</Text>
        <Text style={styles.label}>Order No:</Text>
        <Text style={styles.text}>{route.params.orderNumber}</Text>
        <Text style={styles.label}>Price:</Text>
        <Text style={styles.text}>{'$' + route.params.price}</Text>
        <Text style={styles.label}>Product Name:</Text>
        <Text style={styles.text}>{route.params.productName}</Text>
        <Text style={styles.label}>Customer:</Text>
        <Text style={styles.text}>{route.params.customer.email}</Text>
        <Text style={styles.label}>Order Date:</Text>
        <Text style={styles.text}>{route.params.orderDate}</Text>
        <Text style={styles.label}>Shipping Status:</Text>
        <Text style={styles.text}>{route.params.shippingStatus}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  parent: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    justifyContent: 'center',
  },
  orderContainer: {
    backgroundColor: '#ffffff',
    marginHorizontal: 16,
    borderRadius: 8,
    padding: 16,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 2,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  text: {
    fontSize: 16,
    marginBottom: 8,
  },
});

export default OrderDetails;
