import { View, Text, StyleSheet, FlatList, Pressable } from "react-native";
import React from "react";
import MaterialCommunityIcons from "react-native-vector-icons/FontAwesome";

const EmployeesList = ({ navigation }) => {
  const generateEmployee = ({ item }) => {
    return (
      <Pressable
        style={styles.pressable}
        
      >
        <View style={styles.employee}>
          <Text style={styles.name}>{item.name}</Text>
          <View style={styles.viewButton}>

            <MaterialCommunityIcons
              name="arrow-right"
              size={22}
              style={{  display: "flex",
              flexDirection: "row",
              alignSelf: "center",
              borderWidth: 1,
              borderColor: "#333333",
              borderRadius: 4,
              paddingHorizontal: 12,
              paddingVertical: 8,
              alignItems: "center",
              backgroundColor: "#333333",
              color: "white" }}
              onPress={() =>
                navigation.navigate("EmployeeDetail", {
                  name: item.name,
                  designation: item.designation,
                })
              }
            />
          </View>
        </View>
      </Pressable>
    );
  };

  const employees = [
    { id: 1, name: "John Doe", designation: "CEO" },
    { id: 2, name: "Jane Smith", designation: "DTO" },
    { id: 3, name: "Mike Johnson", designation: "HR HEAD" },
    { id: 4, name: "Emily Davis", designation: "MANAGER" },
    { id: 5, name: "Michael Brown", designation: "LEAD SALES" },
    { id: 6, name: "Sarah Wilson", designation: "BRANCH LEAD" },
    { id: 7, name: "David Thompson", designation: "ENGINEER" },
    { id: 8, name: "Olivia Martin", designation: "ENGINEER" },
    { id: 9, name: "Daniel Anderson", designation: "ENGINEER" },
    { id: 10, name: "Sophia Rodriguez", designation: "ENGINEER" },
  ];

  return (
    <View style={styles.parent}>
      <FlatList
        data={employees}
        renderItem={generateEmployee}
        keyExtractor={(employee) => employee.id.toString()}
        contentContainerStyle={styles.scroll}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  parent: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  employee: {
    borderWidth: 1,
    marginBottom: 8,
    width: "80%",
    borderRadius: 8,
    padding: 12,
    borderColor: "#e0e0e0",
    alignSelf: "center",
    backgroundColor: "#ffffff",
    shadowColor: "#000000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 2,
  },
  name: {
    fontSize: 16,
    textAlign: "center",
    color: "#333333",
    fontWeight: "bold",
    marginBottom: 8,
  },
  scroll: {
    paddingVertical: 24,
    paddingHorizontal: 16,
    backgroundColor: "#f5f5f5",
  },
});

export default EmployeesList;
