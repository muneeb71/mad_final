import { View, Text, StyleSheet, FlatList, Pressable } from "react-native";
import React from "react";
import MaterialCommunityIcons from "react-native-vector-icons/FontAwesome";

const ProductsList = ({ navigation }) => {
  const generateEmployee = ({ item }) => {
    return (
      <Pressable>
        <View style={styles.employee}>
          <Text style={styles.name}>{item.name}</Text>
          <Text style={styles.name}>{"$" + item.price}</Text>
          <View
            style={{
              display: "flex",
              flexDirection: "row",
              justifyContent: 'center',
              alignSelf: "center",
              borderWidth: 1,
              borderColor: "white",
              borderRadius: 4,
              width: "50%",
            }}
          >
            
            <MaterialCommunityIcons
              name="arrow-right"
              size={22}
              style={{
                display: "flex",
                flexDirection: "row",
                alignSelf: "center",
                borderWidth: 1,
                borderColor: "#333333",
                borderRadius: 4,
                paddingHorizontal: 12,
                paddingVertical: 8,
                alignItems: "center",
                backgroundColor: "#333333",
                color: "white"
              }}
              onPress={() =>
                navigation.navigate("ProductDetails", {
                  name: item.name,
                  price: item.price,
                })
              }
            />
          </View>
        </View>
      </Pressable>
    );
  };
  const products = [
    { id: 1, name: "Product 1", price: 19.99 },
    { id: 2, name: "Product 2", price: 29.99 },
    { id: 3, name: "Product 3", price: 9.99 },
    { id: 4, name: "Product 4", price: 39.99 },
    { id: 5, name: "Product 5", price: 14.99 },
    { id: 6, name: "Product 6", price: 24.99 },
    { id: 7, name: "Product 7", price: 49.99 },
    { id: 8, name: "Product 8", price: 12.99 },
    { id: 9, name: "Product 9", price: 34.99 },
    { id: 10, name: "Product 10", price: 17.99 },
  ];

  return (
    <View style={styles.parent}>
      <FlatList
        data={products}
        renderItem={(product) => generateEmployee(product)}
        keyExtractor={(product) => product.id}
        contentContainerStyle={styles.scroll}
      ></FlatList>
    </View>
  );
};

const styles = StyleSheet.create({
  parent: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  employee: {
    borderWidth: 1,
    marginBottom: 8,
    width: "80%",
    borderRadius: 8,
    padding: 12,
    borderColor: "#e0e0e0",
    alignSelf: "center",
    backgroundColor: "#ffffff",
    shadowColor: "#000000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 2,
  },
  name: {
    fontSize: 16,
    textAlign: "center",
    color: "#333333",
    fontWeight: "bold",
    marginBottom: 8,
  },
  scroll: {
    paddingVertical: 24,
    paddingHorizontal: 16,
    backgroundColor: "#f5f5f5",
  },
});

export default ProductsList;
