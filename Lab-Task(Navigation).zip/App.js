import {View, Text} from 'react-native';
import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';

import Home from './src/screens/Home';
import OrderDetails from './src/screens/OrderDetails';
import OrdersList from './src/screens/OrdersList';
import EmployeeDetails from './src/screens/EmployeeDetails';
import EmployeesList from './src/screens/EmployeesList';
import ProductDetails from './src/screens/ProductDetails';
import ProductsList from './src/screens/ProductsList';

const Stack = createNativeStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName={Home}>
        <Stack.Screen name="Home" component={Home} />
        <Stack.Screen name="OrderDetails" component={OrderDetails} />
        <Stack.Screen name="OrdersList" component={OrdersList} />
        <Stack.Screen name="EmployeeDetail" component={EmployeeDetails} />
        <Stack.Screen name="EmployeesList" component={EmployeesList} />
        <Stack.Screen name="ProductDetails" component={ProductDetails} />
        <Stack.Screen name="ProductsList" component={ProductsList} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;
